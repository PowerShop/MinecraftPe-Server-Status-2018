<?php
	require __DIR__ . '/src/MinecraftQuery.php';
	require __DIR__ . '/src/MinecraftQueryException.php';
	
	use xPaw\MinecraftQuery;
	use xPaw\MinecraftQueryException;
	
	$Query = new MinecraftQuery( );
	
	try
	{
		$Query->Connect( '43.229.132.165', '19132' );
		
		
		print_r( $Query->GetInfo( ) );
	}
	catch( MinecraftQueryException $e )
	{
		echo $e->getMessage( );
	}
?>